export const Images = {
    placez: require('../Assets/Images/placez.png').default, 
    got: require('../Assets/Images/giftoftimeImage.png').default,
    sellik: require('../Assets/Images/sellikImage.png').default,
    starname: require('../Assets/Images/starnameImage.png').default,
    streetlogix: require('../Assets/Images/streetlogixImage.png').default,
    videomerger: require('../Assets/Images/VideoMergerImage.png').default,
    wecycle: require('../Assets/Images/wecycleImage.png').default,

    placezAndroid: require('../Assets/Images/androidBadge.png').default,
    placezIos: require('../Assets/Images/appleBadge.png').default,
    webBadge: require('../Assets/Images/website_button.png').default,


}