import React from 'react'
import AppRoutes from '../Routes/index'
import '../App/style.scss'
import "../../node_modules/bootstrap/dist/css/bootstrap.min.css"

function App() {
  return (
       <>
           <AppRoutes />
       </>
  );
}

export default App;
