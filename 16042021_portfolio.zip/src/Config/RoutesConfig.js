const RoutesConfig = {
   PORTFOLIO : '/portfolio'
}
export default RoutesConfig;